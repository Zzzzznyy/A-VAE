# Data folders
output_folder = 'processed'
data_folder = 'data'
